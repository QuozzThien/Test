import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};

serve(async req=>{
  if(req.method==='OPTIONS') return new Response('ok',{headers:cors});
  try{
    const auth=req.headers.get('Authorization');
    if(!auth) return new Response(JSON.stringify({error:'Unauthorized'}),{status:401,headers:{...cors,'Content-Type':'application/json'}});
    const body=await req.json();
    const count=Math.min(Math.max(Number(body.count||10),1),100);
    const subject=String(body.subject||''); const lesson=String(body.lesson||''); const source=String(body.source||''); const difficulty=String(body.difficulty||'mixed'); const extra=String(body.extra||'');
    const apiKey=Deno.env.get('OPENAI_API_KEY'); if(!apiKey) throw new Error('Thiếu OPENAI_API_KEY trong Supabase Secrets');
    const prompt=`Bạn là trợ lý tạo đề trắc nghiệm THPT Việt Nam. Tạo ${count} câu hỏi 4 lựa chọn A/B/C/D. Môn: ${subject}. Bài/chủ đề: ${lesson}. Độ khó: ${difficulty}. Yêu cầu thêm: ${extra}. Nội dung nguồn: ${source}\n\nChỉ trả JSON hợp lệ theo schema: {"questions":[{"question_text":"...","options":["A...","B...","C...","D..."],"answer_index":0,"explanation":"...","difficulty":"nhan_biet|thong_hieu|van_dung"}]}. Không thêm markdown. Không bịa kiến thức nếu nguồn có giới hạn; ưu tiên nội dung nguồn.`;
    const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${apiKey}`,'Content-Type':'application/json'},body:JSON.stringify({model:body.model||'gpt-6-luna',input:[{role:'user',content:prompt}],text:{format:{type:'json_object'}}})});
    if(!r.ok) throw new Error(await r.text());
    const data=await r.json(); const text=data.output_text||''; const parsed=JSON.parse(text);
    return new Response(JSON.stringify(parsed),{headers:{...cors,'Content-Type':'application/json'}});
  }catch(e){return new Response(JSON.stringify({error:String(e?.message||e)}),{status:500,headers:{...cors,'Content-Type':'application/json'}})}
});
